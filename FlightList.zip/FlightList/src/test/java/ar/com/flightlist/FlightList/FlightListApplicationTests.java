package ar.com.flightlist.FlightList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightListApplicationTests {

	@Test
	void contextLoads() {
	}

}
