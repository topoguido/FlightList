package ar.com.flightlist.FlightList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightListApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightListApplication.class, args);
	}

}
